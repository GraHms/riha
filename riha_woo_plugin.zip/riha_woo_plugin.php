<?php
/*
 * Plugin Name:RIHA Payment Gateway
 * Plugin URI: https://www.riha.co.mz
 * Description: Take M-Pesa, RIHA and credit card payments on your store.
 * Author: Ismael GraHms
 * Author URI: https://ismaelgrahms.com
 * Version: 1.0.1
 * Text Domain: riha-woocommerce-plugin
* Domain Path: /languages
* Copyright: © 2017-2019 RIHA Investimentos, Lda.
* License: GNU General Public License v3.0
* License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

 
add_filter( 'woocommerce_payment_gateways', 'riha_add_gateway_class' );
function riha_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Riha_Gateway'; // your class name is here
	return $gateways;
}
/**
 * Adds plugin page links
 *
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_riha_gateway_plugin_links( $links ) {
      $plugin_links = array(
            '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=riha_gateway' ) . '">' . __( 'Configure', 'wc-gateway-riha' ) . '</a>'
      );
      return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_riha_gateway_plugin_links' );



add_action( 'plugins_loaded', 'riha_init_gateway_class' );
function riha_init_gateway_class() {

	class WC_Riha_Gateway extends WC_Payment_Gateway {

 		public function __construct() {

	$this->id = 'riha_gateway'; // payment gateway plugin ID
	$this->icon = ''; // 
	$this->has_fields = true;
	$this->method_title = 'RIHA';
	$this->method_description = 'Description of your RIHA payment gateway'; 
	$this->supports = array(
		'products'
	);
	// Method with all the options fields
	$this->init_form_fields();

	// Load the settings.
	$this->init_settings();
	$this->title = $this->get_option( 'title' );
	$this->description = $this->get_option( 'description' );
	$this->enabled = $this->get_option( 'enabled' );
	$this->testmode = 'yes' === $this->get_option( 'testmode' );
	$this->bscode = $this->get_option( 'bscode' );
	$this->private = $this->testmode ? $this->get_option( 'test_private' ) : $this->get_option( 'private' );
	$this->token= $this->testmode ? $this->get_option( 'test_token' ) : $this->get_option( 'token' );
	$this->shippingdays = $this->testmode ? $this->get_option( 'shippingdays' ) : 7;

	// This action hook saves the settings
	add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );



	// You can also register a webhook here
	add_action( 'woocommerce_api_riha-payment-complete', array( $this, 'webhook' ) );
 }

		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
 		public function init_form_fields(){

	$this->form_fields = array(
		'enabled' => array(
			'title'       => 'Enable/Disable',
			'label'       => 'Enable RIHA Gateway',
			'type'        => 'checkbox',
			'description' => '',
			'default'     => 'no'
		),
		'title' => array(
			'title'       => 'Title',
			'type'        => 'text',
			'description' => 'This controls the title which the user sees during checkout.',
			'default'     => 'RIHA',
			'desc_tip'    => true,
		),
		'description' => array(
			'title'       => 'Description',
			'type'        => 'textarea',
			'description' => 'This controls the description which the user sees during checkout.',
			'default'     => 'Você será redirecionado para o site do riha para finalizar o pagamento..',
		),
		'testmode' => array(
			'title'       => 'Test mode',
			'label'       => 'Enable Test Mode',
			'type'        => 'checkbox',
			'description' => 'Place the payment gateway in test mode using test API keys.',
			'default'     => 'yes',
			'desc_tip'    => true,
		),
		'shippingdays' => array(
			'title'       => 'Your Shipping days',
			'type'        => 'number',
			'default'     => 7,
			'desc_tip'    => true,

		),
		'bscode' => array(
			'title'       => 'Business Code',
			'type'        => 'text'
		),
		'test_token' => array(
			'title'       => 'Test Publishable Token',
			'type'        => 'text'
		),
		'test_private' => array(
			'title'       => 'Test Private Key',
			'type'        => 'password',
		),
		'token' => array(
			'title'       => 'Live Publishable Token',
			'type'        => 'text'
		),
		'private' => array(
			'title'       => 'Live Private Key',
			'type'        => 'password'
		)
	);
}





		public function process_payment( $order_id ) {

				global $woocommerce;

				// we need it to get any order detailes


				 $order = wc_get_order( $order_id );
                   $order_data = $order->get_data(); // The Order data
                  $success_url = $order->get_checkout_order_received_url(); //get_site_url().'/wc-api/WC_Gateway_riha';
									$webhook_url = get_site_url().'/wc-api/riha-payment-complete?id='.$order_id;

				/*
			 	 * Array with parameters for API interaction
				 */
				$args = array(

					'token'     => $this->token,
                  'secretkey'   => $this->private,
                  'bskey'       => $this->bscode



				);

				/*
				 * Your API interaction could be built with wp_remote_post()
			 	 */
				 //$response = wp_remote_post('https://sandbox.riha.co.mz/token-terminal/', $args );

				 $fields_string = http_build_query($args);
					//open connection
					$ch = curl_init();
					//set the url, number of POST vars, POST data
					curl_setopt($ch,CURLOPT_URL, 'https://sandbox.riha.co.mz/token-terminal/');
					curl_setopt($ch,CURLOPT_POST, true);
					curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
					//So that curl_exec returns the contents of the cURL; rather than echoing it
					curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
					//execute post
					$response = curl_exec($ch);


				 if( !is_wp_error( $response ) ) {

					 $body = json_decode( $response, true );

					 // it could be different depending on your payment processor
					 if ( $body['status'] == 'success' ) {




			 				$args = array('bstype' =>  $body['bstype'],
			                      'accesskey' =>  $body['accesskey'],
			                      'buyer' => $order_data['billing']['email'],
			                      'return'  => $success_url, //url where IPN messages will be sent after purchase, then validate in the ipn() method
			                      'amount' => strval($order->get_total()), // product price (shoud be a double value)
			                      'paymentId'=> $webhook_url,
			                      'shdays' => strval($this->shippingdays));

			 				$fields_string = http_build_query($args);
			 				curl_setopt($ch,CURLOPT_URL, 'https://sandbox.riha.co.mz/product/');
							curl_setopt($ch,CURLOPT_POST, true);
							curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
							//So that curl_exec returns the contents of the cURL; rather than echoing it
							curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
							//execute post
							$response = curl_exec($ch);

			 			 if (!is_wp_error( $response ) ) {
			 			 	$body = json_decode( $response, true );
			 			 	if ( $body['status'] == 'success' ){

			 			 		$order->update_status( 'on-hold', __( 'Awaiting riha payment', 'woocommerce' ) );
			 			 		$woocommerce->cart->empty_cart();
					 			$redirect = 'https://checkout.riha.co.mz/auth.php?q='.$body['url'];

					 			   return array(
												'result' => 'success',
												'redirect' => $redirect
											);


			 			 	}else {
						wc_add_notice( $body['message'], 'error' );
						return;
			 			 }

						// some notes to customer (replace true with false to make it private)


					 } else {
						wc_add_notice(  $body['message'], 'error' );
						return;
					}

				} else {
					wc_add_notice(  $body['message'], 'error' );
					return;
				}

			}

			 	}


			 	public function webhook() {

				$order = wc_get_order( $_GET['id'] );
				$order->payment_complete();
				$order->reduce_order_stock();

				update_option('webhook_debug', $_GET);
}

	 }
}
